<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Crear Categoría</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <ion-card>
        <ion-card-header>
          <ion-card-title>Nueva Categoría</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <form @submit.prevent="crearCategoria">
            <ion-item>
              <ion-label position="stacked">Nombre de la Categoría</ion-label>
              <ion-input v-model="nombreCategoria" required></ion-input>
            </ion-item>
            <ion-button type="submit" expand="block" color="primary" class="mt-2">
              Crear
            </ion-button>
          </form>
          <ion-text v-if="mensaje" color="success">{{ mensaje }}</ion-text>
        </ion-card-content>
      </ion-card>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref } from 'vue';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent,
  IonItem, IonLabel, IonInput, IonButton, IonText
} from '@ionic/vue';
import axios from 'axios';

const nombreCategoria = ref('');
const mensaje = ref('');

const crearCategoria = async () => {
  if (!nombreCategoria.value) return;
  try {
    await axios.post('http://localhost:3000/api/categories', {
      name: nombreCategoria.value
    });
    mensaje.value = '¡Categoría creada!';
    nombreCategoria.value = '';
  } catch (error) {
    mensaje.value = 'Error al crear la categoría';
  }
};
</script>

<style scoped>
.mt-2 {
  margin-top: 16px;
}
</style>