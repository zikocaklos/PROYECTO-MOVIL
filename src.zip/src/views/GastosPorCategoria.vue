<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-title>Gastos por Categoría</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <ion-card>
        <ion-card-header>
          <ion-card-title>Resumen de Gastos</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <table class="expense-table">
            <thead>
              <tr>
                <th>Categoría</th>
                <th>Total Gastado</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(total, category) in gastosPorCategoria" :key="category">
                <td>{{ category }}</td>
                <td>${{ total.toFixed(2) }}</td>
              </tr>
              <tr v-if="Object.keys(gastosPorCategoria).length === 0">
                <td colspan="2">No hay datos</td>
              </tr>
            </tbody>
          </table>
        </ion-card-content>
      </ion-card>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent
} from '@ionic/vue';
import axios from 'axios';

const gastosPorCategoria = ref({});

const fetchGastosPorCategoria = async () => {
  try {
    const { data } = await axios.get('http://localhost:3000/api/expenses');
    // Agrupar por categoría
    const resumen = {};
    data.forEach(expense => {
      if (!resumen[expense.category]) resumen[expense.category] = 0;
      resumen[expense.category] += Number(expense.amount);
    });
    gastosPorCategoria.value = resumen;
  } catch (error) {
    gastosPorCategoria.value = {};
  }
};

onMounted(fetchGastosPorCategoria);
</script>

<style scoped>
.expense-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 14px;
  background: #f8fafc;
  border-radius: 10px;
  overflow: hidden;
}
.expense-table th,
.expense-table td {
  border-bottom: 1px solid #e0eafc;
  padding: 12px 8px;
  text-align: center;
  font-size: 1rem;
}
.expense-table th {
  background: #0d3b66;
  color: #fff;
  font-weight: 700;
  letter-spacing: 1px;
}
</style>