<template>
  <ion-page>
    <ion-header>
      <ion-toolbar color="primary">
        <ion-buttons slot="start">
          <ion-button @click="goHome">
            <ion-icon slot="icon-only" name="arrow-back-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
        <ion-title>Gastos del Mes</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding monthly-bg">
      <!-- Filtro de mes -->
      <div class="month-filter">
        <ion-label position="stacked" class="month-label">Seleccionar mes</ion-label>
        <ion-datetime
          v-model="selectedMonth"
          presentation="month"
          @ionChange="fetchExpenses"
          class="month-picker"
        />
      </div>

      <!-- Botón para descargar Excel -->
      <ion-button expand="block" color="success" @click="descargarExcel" style="margin-bottom: 16px;">
        Descargar Excel
      </ion-button>

      <!-- Tabla de Gastos -->
      <ion-card class="expense-card">
        <ion-card-header>
          <ion-card-title>Gastos por Categoría</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <table class="expense-table">
            <thead>
              <tr>
                <th>Categoría</th>
                <th>Monto</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(expense, index) in monthlyExpenses" :key="index">
                <td>{{ expense.category }}</td>
                <td>
                  <span class="amount">${{ expense.amount.toFixed(2) }}</span>
                </td>
              </tr>
              <tr v-if="monthlyExpenses.length === 0">
                <td colspan="2" class="no-data">No hay gastos registrados para este mes.</td>
              </tr>
            </tbody>
          </table>

          <!-- Total de Gastos -->
          <div class="total-row">
            <span class="total-label">Total Gastado:</span>
            <ion-text color="primary" class="total-amount">${{ totalAmount.toFixed(2) }}</ion-text>
          </div>
        </ion-card-content>
      </ion-card>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import {
  IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonLabel, IonDatetime,
  IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonButton, IonButtons, IonText, IonIcon
} from '@ionic/vue';
import axios from 'axios';

// Importa SheetJS (xlsx)
import * as XLSX from 'xlsx';

const router = useRouter();
const selectedMonth = ref('');
const monthlyExpenses = ref([]);
const totalAmount = ref(0);

const fetchExpenses = async () => {
  if (!selectedMonth.value) return;

  const { data } = await axios.get('http://localhost:3000/api/expenses', {
    params: { month: selectedMonth.value }
  });

  monthlyExpenses.value = data;
  totalAmount.value = data.reduce((sum, expense) => sum + parseFloat(expense.amount), 0);
};

const goHome = () => {
  router.push('/home');
};

// Función para descargar Excel
const descargarExcel = () => {
  if (!monthlyExpenses.value.length) {
    alert('No hay datos para exportar.');
    return;
  }
  // Prepara los datos
  const wsData = [
    ['Categoría', 'Monto'],
    ...monthlyExpenses.value.map(exp => [exp.category, exp.amount])
  ];
  // Crea la hoja y el libro
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'GastosMes');
  // Descarga el archivo
  XLSX.writeFile(wb, 'gastos_mes.xlsx');
};

onMounted(fetchExpenses);
watch(selectedMonth, fetchExpenses);
</script>

<style scoped>
.monthly-bg {
  --background: linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%);
  min-height: 100vh;
}

.month-filter {
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.month-label {
  font-weight: 600;
  color: #0d3b66;
  margin-bottom: 6px;
  font-size: 1.1rem;
}

.month-picker {
  width: 100%;
  max-width: 320px;
  border-radius: 8px;
  background: #fff;
  box-shadow: 0 2px 8px rgba(13, 59, 102, 0.05);
  padding: 8px 0;
}

.expense-card {
  border-radius: 16px;
  box-shadow: 0 4px 18px rgba(13, 59, 102, 0.10);
  margin-top: 12px;
}

.expense-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 14px;
  background: #f8fafc;
  border-radius: 10px;
  overflow: hidden;
}

.expense-table th,
.expense-table td {
  border-bottom: 1px solid #e0eafc;
  padding: 12px 8px;
  text-align: center;
  font-size: 1rem;
}

.expense-table th {
  background: #0d3b66;
  color: #fff;
  font-weight: 700;
  letter-spacing: 1px;
}

.amount {
  color: #2196f3;
  font-weight: 600;
}

.no-data {
  color: #b0b0b0;
  font-style: italic;
  padding: 18px 0;
}

.total-row {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin-top: 18px;
  gap: 10px;
  font-size: 1.15rem;
}

.total-label {
  font-weight: 700;
  color: #0d3b66;
}

.total-amount {
  font-weight: bold;
  font-size: 1.2em;
}

@media (max-width: 600px) {
  .expense-card {
    margin-top: 8px;
    padding: 0 2px;
  }
  .expense-table th, .expense-table td {
    font-size: 0.95rem;
    padding: 8px 4px;
  }
  .month-picker {
    max-width: 100vw;
  }
}
</style>