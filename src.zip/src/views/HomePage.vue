<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-button slot="start" fill="clear" @click="showAddExpenseModal = true">
          Agregar Gasto
        </ion-button>
        <ion-title>Bienvenido a GastoContro</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-card>
        <ion-card-header>
          <ion-card-title>Presupuesto Mensual</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <ion-item>
            <ion-label position="floating">Presupuesto</ion-label>
            <ion-input :value="monthlyBudget" readonly></ion-input>
          </ion-item>
        </ion-card-content>
      </ion-card>

      <div class="category-buttons">
        <ion-button
          v-for="category in categories"
          :key="category"
          expand="block"
          @click="goToCategory(category)"
        >
          {{ category }}
        </ion-button>
        <ion-button expand="block" color="success" @click="goToCrearCategoria">
          Crear Nueva Categoría
        </ion-button>
      </div>

      <ion-button expand="block" color="primary" @click="goToCalculateExpenses" class="small-button">
        Calcular Gastos
      </ion-button>

      <ion-list>
        <ion-item v-for="expense in expenses" :key="expense._id">
          <ion-label>
            {{ expense.name }} - {{ expense.category }} - ${{ expense.amount }}
          </ion-label>
        </ion-item>
      </ion-list>

      <ion-button expand="block" color="secondary" class="add-money-button" @click="showAddMoneyModal = true">
        Agregar Dinero
      </ion-button>

      <!-- Modal para agregar gasto -->
      <ion-modal :is-open="showAddExpenseModal" @did-dismiss="showAddExpenseModal = false">
        <ion-content class="ion-padding">
          <h2>Agregar Gasto</h2>
          <ion-item>
            <ion-label position="stacked">Nombre del Gasto</ion-label>
            <ion-input v-model="newExpense.name" placeholder="Ej: Supermercado"></ion-input>
          </ion-item>
          <ion-item>
            <ion-label position="stacked">Monto</ion-label>
            <ion-input v-model.number="newExpense.amount" type="number" placeholder="Ej: 100"></ion-input>
          </ion-item>
          <ion-item>
            <ion-label position="stacked">Categoría</ion-label>
            <ion-select v-model="newExpense.category" placeholder="Selecciona una categoría">
              <ion-select-option v-for="cat in categories" :key="cat" :value="cat">{{ cat }}</ion-select-option>
            </ion-select>
          </ion-item>
          <ion-button expand="block" color="primary" @click="addExpense">Guardar</ion-button>
          <ion-button expand="block" color="medium" @click="showAddExpenseModal = false">Cancelar</ion-button>
        </ion-content>
      </ion-modal>

      <!-- Modal para agregar dinero -->
      <ion-modal :is-open="showAddMoneyModal" @did-dismiss="showAddMoneyModal = false">
        <ion-content class="ion-padding">
          <h2>Agregar Dinero</h2>
          <ion-item>
            <ion-label position="stacked">¿Cuánto dinero llegó?</ion-label>
            <ion-input v-model.number="moneyToAdd" type="number" placeholder="Ej: 500"></ion-input>
          </ion-item>
          <ion-button expand="block" color="primary" @click="addMoney">Guardar</ion-button>
          <ion-button expand="block" color="medium" @click="showAddMoneyModal = false">Cancelar</ion-button>
        </ion-content>
      </ion-modal>
    </ion-content>
  </ion-page>
</template>

<script setup>
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonList,
  IonItem,
  IonLabel,
  IonInput,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonModal,
  IonSelect,
  IonSelectOption
} from '@ionic/vue';

import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const categories = [
  'Alimentos',
  'Transporte',
  'Salud',
  'Entretenimiento',
  'Educación'
];

const expenses = ref([
  { _id: 0, name: 'Renta', category: 'Alquiler', amount: 500 },
  { _id: 1, name: 'Supermercado', category: 'Alimentos', amount: 120 },
  { _id: 2, name: 'Bus', category: 'Transporte', amount: 50 },
  { _id: 3, name: 'Farmacia', category: 'Salud', amount: 80 },
  { _id: 4, name: 'Cine', category: 'Entretenimiento', amount: 60 },
  { _id: 5, name: 'Libros', category: 'Educación', amount: 100 }
]);

const monthlyBudget = ref(1000);

const showAddMoneyModal = ref(false);
const showAddExpenseModal = ref(false);

const moneyToAdd = ref(null);

const newExpense = ref({
  name: '',
  category: '',
  amount: null
});

const addMoney = () => {
  if (!moneyToAdd.value || moneyToAdd.value <= 0) {
    alert('Ingresa un monto válido');
    return;
  }
  monthlyBudget.value += moneyToAdd.value;
  moneyToAdd.value = null;
  showAddMoneyModal.value = false;
};

const addExpense = () => {
  if (!newExpense.value.name || !newExpense.value.category || !newExpense.value.amount) {
    alert('Completa todos los campos');
    return;
  }
  expenses.value.push({
    _id: Date.now(),
    name: newExpense.value.name,
    category: newExpense.value.category,
    amount: newExpense.value.amount
  });
  newExpense.value = { name: '', category: '', amount: null };
  showAddExpenseModal.value = false;
};


const goToCalculateExpenses = () => {
  router.push('/monthly-expenses');
};

const goToCategory = (category) => {
  router.push(`/gatocategoria/${category}`);
};

const goToCrearCategoria = () => {
  router.push('/crear-categoria');
};
</script>

<style scoped>
ion-card {
  background-color: #1e1e2f;
  color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

ion-card-title {
  font-size: 1.3rem;
  font-weight: bold;
  text-align: center;
}

ion-item {
  --background: transparent;
  --color: white;
  margin-bottom: 12px;
}

ion-input {
  --color: white;
  font-weight: bold;
  text-align: center;
}

.category-buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 20px;
}

ion-button {
  --border-radius: 10px;
  font-size: 1rem;
}

.small-button {
  margin-top: 20px;
}

.add-money-button {
  margin-top: 20px;
}

ion-list {
  margin-top: 20px;
  background-color: transparent;
}

ion-item ion-label {
  color: white;
}
</style>
