import { createRouter, createWebHistory } from '@ionic/vue-router';
import { RouteRecordRaw } from 'vue-router';
import HomePage from '../views/HomePage.vue';
import LoginPague from '@/views/LoginPague.vue';
import CrearcuentaPage from '@/views/CrearcuentaPage.vue';
import BienvenidaPague from '@/views/BienvenidaPague.vue';
import MensualPague from '@/views/MensualPague.vue';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: '/bienvenido'
  },
  {
    path: '/home',
    name: 'Home',
    component: HomePage
  },
  {
    path: '/login',
    name: 'login',
    component: LoginPague
  },
  {
    path: '/crearcuenta',
    name: 'crear-cuenta',
    component: CrearcuentaPage
  },
  {
    path: '/register',
    redirect: '/crearcuenta' 
  },
  {
    path: '/bienvenido',
    name: 'bienvenido',
    component: BienvenidaPague
  },
  {
    path: '/mensual',
    name: 'mensual',
    component: MensualPague
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
});

export default router;
