import { Sequelize } from 'sequelize';

// Usa una base de datos diferente si estás en test
const dbName = process.env.NODE_ENV === 'test' ? 'gastocontro_test' : 'gastocontro';

const sequelize = new Sequelize(dbName, 'postgres', '123456789', {
  host: 'localhost',
  dialect: 'postgres',
  logging: false, // Opcional: desactiva logs SQL en consola
});

export default sequelize;
