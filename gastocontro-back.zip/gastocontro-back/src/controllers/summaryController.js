import Transaction from '../models/Transaction.js';
import Category from '../models/Category.js';
import Expense from '../models/Expense.js';
import Income from '../models/Income.js';
import { Op } from 'sequelize';

export const monthlySummary = async (req, res) => {
  const userId = req.user.id;
  const { month, year } = req.query;

  if (!month || !year) {
    return res.status(400).json({ error: 'Mes y año requeridos' });
  }

  const startDate = `${year}-${month.toString().padStart(2, '0')}-01`;
  const endDate = `${year}-${month.toString().padStart(2, '0')}-31`;

  try {
    // Total gastos
    const totalExpenses = await Expense.sum('amount', {
      where: {
        userId,
        date: { [Op.between]: [startDate, endDate] },
      },
    });

    // Total ingresos
    const totalIncomes = await Income.sum('amount', {
      where: {
        userId,
        date: { [Op.between]: [startDate, endDate] },
      },
    });

    // Gastos por categoría
    const expensesByCategory = await Expense.findAll({
      attributes: [
        'categoryId',
        [Expense.sequelize.fn('SUM', Expense.sequelize.col('amount')), 'total'],
      ],
      where: {
        userId,
        date: { [Op.between]: [startDate, endDate] },
      },
      group: ['categoryId'],
      raw: true,
    });

    // Obtener nombres de categorías
    const categoryIds = expensesByCategory.map((e) => e.categoryId).filter(Boolean);
    let categories = [];
    if (categoryIds.length > 0) {
      categories = await Category.findAll({
        where: { id: categoryIds },
        raw: true,
      });
    }

    // Calcular porcentaje por categoría
    const total = totalExpenses || 0;
    const categoryPercentages = expensesByCategory.map((e) => {
      const cat = categories.find((c) => c.id === e.categoryId);
      return {
        categoryId: e.categoryId,
        category: cat ? cat.name : 'Sin categoría',
        total: Number(e.total),
        percentage: total ? Number(((e.total / total) * 100).toFixed(2)) : 0,
      };
    });

    res.json({
      month,
      year,
      totalIncomes: totalIncomes || 0,
      totalExpenses: totalExpenses || 0,
      balance: (totalIncomes || 0) - (totalExpenses || 0),
      categoryPercentages,
    });
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener el resumen mensual' });
  }
};
// Exporta también como getSummary para compatibilidad con rutas antiguas
export const getSummary = monthlySummary;
