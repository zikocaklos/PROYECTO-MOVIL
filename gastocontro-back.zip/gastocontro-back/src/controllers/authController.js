// ...existing code...
import User from '../models/User.js';
// import jwt from 'jsonwebtoken';

export const register = async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Nombre, email y contraseña requeridos' });

  try {
    // Puedes agregar lógica para validar si el usuario ya existe
    const exists = await User.findOne({ where: { email } });
    if (exists) return res.status(400).json({ error: 'El email ya está registrado' });

    // Crea el usuario (ajusta según tu modelo)
    const user = await User.create({ name, email, password });
    res.json({ message: 'Usuario registrado', user: { id: user.id, name: user.name, email: user.email } });
  } catch (error) {
    res.status(500).json({ error: 'Error al registrar usuario' });
  }
};

export const login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Usuario y contraseña requeridos' });

  const user = await User.findOne({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Credenciales inválidas' });

  const valid = await user.validatePassword(password);
  if (!valid) return res.status(401).json({ error: 'Credenciales inválidas' });

  res.json({ id: user.id, name: user.name, email: user.email });
};
// ...existing code...