import Category from '../models/Category.js';
import { Op } from 'sequelize';

// Crear categoría
export const createCategory = async (req, res) => {
  try {
    const { name, userId } = req.body; // userId opcional
    if (!name) return res.status(400).json({ error: 'Nombre requerido' });
    const category = await Category.create({ name, userId: userId || null });
    res.status(201).json(category);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear categoría' });
  }
};

// Listar categorías (globales y del usuario)
export const listCategories = async (req, res) => {
  try {
    const userId = req.query.userId || null; // userId opcional por query
    const where = userId
      ? { [Op.or]: [{ userId: null }, { userId }] }
      : { userId: null };
    const categories = await Category.findAll({ where });
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: 'Error al listar categorías' });
  }
};

// Editar categoría personalizada
export const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, userId } = req.body;
    const [updated] = await Category.update(
      { name },
      { where: { id, userId } }
    );
    if (!updated) return res.status(404).json({ error: 'Categoría no encontrada o sin cambios' });
    const category = await Category.findOne({ where: { id, userId } });
    res.json(category);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar categoría' });
  }
};

// Eliminar categoría personalizada
export const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.body.userId; // userId opcional por body
    const deleted = await Category.destroy({ where: { id, userId } });
    if (!deleted) return res.status(404).json({ error: 'Categoría no encontrada' });
    res.json({ message: 'Categoría eliminada' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar categoría' });
  }
};
