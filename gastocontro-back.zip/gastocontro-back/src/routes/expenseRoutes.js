import express from 'express';
import { 
  createExpense, 
  listExpenses, 
  updateExpense, 
  deleteExpense, 
  exportExpensesCSV, 
  expenseHistory 
} from '../controllers/expenseController.js';

const router = express.Router();

router.post('/', createExpense);
router.get('/', listExpenses);
router.put('/:id', updateExpense);
router.delete('/:id', deleteExpense);
router.get('/export/csv', exportExpensesCSV);
router.get('/history', expenseHistory);

export default router;