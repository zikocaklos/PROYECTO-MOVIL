import express from 'express';
// import auth from '../middleware/auth.js';
import {
  createIncome,
  listIncomes,
  getIncome,
  updateIncome,
  deleteIncome
} from '../controllers/incomeController.js';

const router = express.Router();

router.post('/', createIncome);
router.get('/', listIncomes);
router.get('/:id', getIncome);
router.put('/:id', updateIncome);
router.delete('/:id', deleteIncome);

export default router;