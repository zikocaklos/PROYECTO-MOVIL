import express from 'express';
import sequelize from './config/database.js';
import dotenv from 'dotenv';
import cors from 'cors';

import initModels from './models/index.js'; // ✅ usa el nuevo archivo de modelos

// Rutas
import routes from './routes/index.js';
import authRoutes from './routes/auth.js';
import historyRoutes from './routes/history.js';
import categoryRoutes from './routes/categoryRoutes.js';
import summaryRoutes from './routes/summaryRoutes.js';
import limitRoutes from './routes/limitRoutes.js';

dotenv.config();

const app = express();

app.use(cors({
  origin: 'http://localhost:8100'
}));

app.use(express.json());

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api', routes);
app.use('/api/categories', categoryRoutes);
app.use('/api/summary', summaryRoutes);
app.use('/api/history', historyRoutes);
app.use('/api/limits', limitRoutes);

initModels(sequelize); // ✅ inicializa los modelos y relaciones

sequelize.sync().then(() => {
  console.log('Modelos sincronizados con la base de datos');
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`API lista en :${PORT}`));
}).catch((err) => {
  console.error('Error al sincronizar modelos:', err);
});

export default app;
