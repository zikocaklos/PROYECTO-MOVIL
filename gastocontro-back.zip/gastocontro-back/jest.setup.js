import dotenv from 'dotenv';
import { sequelize } from './src/db.js';

const envFile = process.env.NODE_ENV === 'test' ? '.env.test' : '.env';
dotenv.config({ path: envFile });

beforeAll(async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync({ force: true }); // limpia DB antes de testear
    console.log('Conexión a DB establecida para tests.');
  } catch (error) {
    console.error('Error de conexión a DB:', error);
  }
});

afterAll(async () => {
  await sequelize.close();
});
