import request from 'supertest';
import app from '../src/app.js';
import sequelize  from '../src/config/database.js';

beforeAll(async () => {
  await sequelize.sync({ force: true });
});

afterAll(async () => {
  await sequelize.close();
});

describe('Expenses endpoint', () => {
  test('crea gasto válido', async () => {
    const res = await request(app)
      .post('/api/expenses')
      .send({ amount: 100, description: 'Cena', spentAt: '2025-05-19' });
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('id');
  });

  test('rechaza amount negativo', async () => {
    const res = await request(app)
      .post('/api/expenses')
      .send({ amount: -10 });
    expect(res.statusCode).toBe(400);
    expect(res.body.errors[0].field).toBe('amount');
  });
});

describe('Gastos API', () => {
  it('Debe rechazar crear gasto sin autenticación', async () => {
    const res = await request(app)
      .post('/api/expenses')
      .send({ amount: 100, spentAt: '2024-06-01' });
    expect(res.statusCode).toBe(401);
  });

  // Puedes agregar más tests autenticando y probando el CRUD completo
});
