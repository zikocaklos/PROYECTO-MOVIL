import request from 'supertest';
import app from '../src/app.js';
import sequelize  from '../src/config/database.js';


beforeAll(async () => {
  await sequelize.sync({ force: true }); // limpia la BD antes de los tests
});

afterAll(async () => {
  await sequelize.close();
});

describe('Categories endpoint', () => {
  test('crea categoría válida', async () => {
    const res = await request(app)
      .post('/api/categories')
      .send({ name: 'Alimentos' });
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('id');
    expect(res.body.name).toBe('Alimentos');
  });

  test('rechaza categoría sin nombre', async () => {
    const res = await request(app)
      .post('/api/categories')
      .send({ name: '' });
    expect(res.statusCode).toBe(400);
    expect(res.body.errors[0].field).toBe('name');
  });

  test('lista categorías', async () => {
    const res = await request(app)
      .get('/api/categories');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThan(0);
  });
});
