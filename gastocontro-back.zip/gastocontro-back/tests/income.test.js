import request from 'supertest';
import app from '../src/app.js';
import  sequelize from '../src/config/database.js';

beforeAll(async () => {
  await sequelize.sync({ force: true }); // BD limpia
});

afterAll(async () => {
  await sequelize.close();
});

describe('Incomes endpoint', () => {
  test('crea ingreso válido', async () => {
    const res = await request(app)
      .post('/api/incomes')
      .send({ amount: 500 });
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('id');
  });

  test('rechaza amount negativo', async () => {
    const res = await request(app)
      .post('/api/incomes')
      .send({ amount: -10 });
    expect(res.statusCode).toBe(400);
    expect(res.body.errors[0].field).toBe('amount');
  });
});
