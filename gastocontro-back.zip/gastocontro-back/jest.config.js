export default {
  testEnvironment: 'node'
};
