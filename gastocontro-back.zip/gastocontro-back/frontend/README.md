# Frontend Vue + Ionic para Gastocontro

## 1. Instala Ionic CLI

```bash
npm install -g @ionic/cli
```

## 2. Crea el proyecto

```bash
ionic start gastocontro-frontend blank --type=vue
cd gastocontro-frontend
```

## 3. Instala Axios

```bash
npm install axios
```

## 4. Configura Axios

Crea el archivo `src/api.js`:

```js
// filepath: src/api.js
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:3000/api' // Cambia por la URL de tu backend si es necesario
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
```

## 5. Ejemplo de Login

Crea o edita `src/views/Login.vue`:

```vue
<!-- filepath: src/views/Login.vue -->
<template>
  <ion-page>
    <ion-content>
      <ion-input v-model="email" placeholder="Email" />
      <ion-input v-model="password" type="password" placeholder="Contraseña" />
      <ion-button @click="login">Iniciar sesión</ion-button>
      <div v-if="error">{{ error }}</div>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref } from 'vue';
import api from '../api';

const email = ref('');
const password = ref('');
const error = ref('');

const login = async () => {
  try {
    const res = await api.post('/auth/login', { email: email.value, password: password.value });
    localStorage.setItem('token', res.data.token);
    // Redirige a la pantalla principal
  } catch (e) {
    error.value = 'Credenciales incorrectas';
  }
};
</script>
```

## 6. Corre la app en modo desarrollo

```bash
ionic serve
```

## 7. Compila como app móvil

```bash
ionic build
ionic cap add android
ionic cap open android
# O para iOS:
# ionic cap add ios
# ionic cap open ios
```

---

**¡Listo! Ahora puedes desarrollar tu app móvil con Vue + Ionic y consumir tu backend.**
